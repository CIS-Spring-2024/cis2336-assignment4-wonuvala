document.getElementById('orderForm').addEventListener('submit', function(event) {
    event.preventDefault(); // Prevent form submission

    // Validate quantities
    var burgerQty = parseInt(document.getElementById('burgerQty').value);
    if (burgerQty < 1 || burgerQty > 10 || isNaN(burgerQty)) {
        document.getElementById('orderMessage').textContent = 'Please enter a quantity between 1 and 10 for the burger.';
        return;
    }

    // Other validation checks for additional items if needed

    // Form is valid, process order
    var name = document.getElementById('name').value;
    var email = document.getElementById('email').value;

    // Example: Send order data to a server or display a confirmation message
    document.getElementById('orderMessage').textContent = `Order placed for ${burgerQty} burger(s) by ${name} (${email}).`;
});
